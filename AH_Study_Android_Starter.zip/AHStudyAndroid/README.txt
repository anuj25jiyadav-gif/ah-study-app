AH Study Android starter project

This is an Android Studio project source package, not a compiled APK.

Build steps:
1. Install Android Studio on a computer.
2. Open Android Studio and choose Open.
3. Select this AHStudy folder (the folder containing settings.gradle).
4. Wait for Gradle sync to finish. Install the Android SDK Platform 35 if prompted.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location when the build completes.

App details:
- Education-only AH Study interface bundled locally.
- JavaScript and local browser storage enabled for the demo.
- Educational video search opens YouTube search in the external browser/app.
- No real student accounts, hosted video library, cloud sync, or backend are included yet.
